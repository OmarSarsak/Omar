import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AddToTheCart {
    public static void main(String[] args) throws InterruptedException {
       WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");
        //Register
        driver.findElement(By.id("login2")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("loginusername")));//visibilty of first element.
        driver.findElement(By.id("loginusername")).sendKeys("Omar.salah10@gmail.com");
        driver.findElement(By.id("loginpassword")).sendKeys("Omar@1234");
        driver.findElement(By.xpath("//button[@onclick='logIn()']")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Samsung galaxy s6')]")));
        Thread.sleep(10000);
        driver.findElement(By.xpath("//*[contains(text(),'Samsung galaxy s6')]")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Add to cart')]")));
        driver.findElement(By.xpath("//*[contains(text(),'Add to cart')]")).click();






    }
}
