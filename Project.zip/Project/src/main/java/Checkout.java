import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Checkout {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");

        driver.findElement(By.id("login2")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("loginusername")));//visibilty of first element.
        driver.findElement(By.id("loginusername")).sendKeys("Omar.salah10@gmail.com");
        driver.findElement(By.id("loginpassword")).sendKeys("Omar@1234");
        driver.findElement(By.xpath("//button[@onclick='logIn()']")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("cartur")));
        Thread.sleep(5000);
        driver.findElement(By.id("cartur")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Place Order')]")));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[contains(text(),'Place Order')]")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("name"))).sendKeys("Omar");
        Thread.sleep(1000);
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("country"))).sendKeys("Jordan");
        Thread.sleep(1000);
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("city"))).sendKeys("Amman");
        Thread.sleep(1000);
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("card"))).sendKeys("411111111111111");
        Thread.sleep(1000);
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("month"))).sendKeys("Jul");
        Thread.sleep(1000);
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("year"))).sendKeys("2023");
        Thread.sleep(1000);
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Purchase')]"))).click();
        Thread.sleep(1000);




    }
}
